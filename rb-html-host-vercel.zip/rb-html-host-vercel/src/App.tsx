import { useCallback, useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import { toast } from "sonner";
import {
  ArrowUpRight, Download, FileCode2, Globe, Loader2, LogOut, Pencil, Rocket, Trash2, UploadCloud, X,
} from "lucide-react";
import * as api from "./api";
import type { Project, Session } from "./api";

const errMsg = (e: unknown) => (e instanceof Error ? e.message : "Connection failed.");

export default function App() {
  const [session, setSession] = useState<Session | null | undefined>(undefined);
  const [slow, setSlow] = useState(false);

  const refresh = useCallback(async () => {
    const t = setTimeout(() => setSlow(true), 3000);
    try { setSession(await api.getSession()); } catch { setSession(null); }
    finally { clearTimeout(t); setSlow(false); }
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  return (
    <div className="min-h-screen">
      <header className="mx-auto flex max-w-5xl items-center justify-between px-5 py-5">
        <div className="flex items-center gap-2 font-mono text-sm font-bold tracking-tight">
          <span className="grid size-7 place-items-center rounded-md bg-primary text-primary-foreground">&gt;_</span>
          WEB_HTML<span className="text-primary">HOST</span>
        </div>
        {session && (
          <button
            onClick={async () => { await api.logout().catch(() => {}); refresh(); }}
            className="flex items-center gap-2 rounded-md border px-3 py-1.5 font-mono text-xs text-muted-foreground transition hover:border-primary hover:text-foreground"
          >
            @{session.username} <LogOut className="size-3.5" />
          </button>
        )}
      </header>

      {session === undefined && (
        <div className="grid min-h-[70vh] place-items-center text-center">
          <div>
            <Loader2 className="mx-auto size-8 animate-spin text-primary" />
            <p className="mt-4 font-mono text-sm text-muted-foreground">
              {slow ? "Still loading…" : "Connecting…"}
            </p>
          </div>
        </div>
      )}
      {session === null && <AuthView onDone={refresh} />}
      {session && <Dashboard session={session} refresh={refresh} />}
    </div>
  );
}

/* ---------------- Auth ---------------- */

function AuthView({ onDone }: { onDone: () => void }) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      await api.auth(mode, user, pass);
      if (mode === "register") {
        toast.success("Account created!");
      }
      onDone();
    } catch (e) { toast.error(errMsg(e)); }
    finally { setBusy(false); }
  }

  return (
    <main className="mx-auto grid max-w-5xl gap-12 px-5 pb-16 pt-6 md:grid-cols-2 md:items-center md:pt-16">
      <section className="animate-rise">
        <p className="font-mono text-xs uppercase tracking-[0.2em] text-primary">// static hosting</p>
        <h1 className="mt-4 text-5xl font-bold leading-[1.02] tracking-tight md:text-6xl">
          Drop HTML.<br />Get a URL.<span className="caret text-primary">_</span>
        </h1>
        <p className="mt-5 max-w-sm text-muted-foreground">
          Upload a single file and it's live on your own subdomain. Update it anytime, every version kept.
        </p>
        <div className="mt-8 inline-flex items-center gap-2 rounded-md border bg-card px-3 py-2 font-mono text-sm">
          <Globe className="size-4 text-primary" /><span className="text-muted-foreground">{api.HOST_PREFIX}</span>yoursite
        </div>
      </section>

      <section className="animate-rise rounded-xl border bg-card p-6 md:p-8" style={{ animationDelay: "80ms" }}>
        <div className="mb-6 grid grid-cols-2 rounded-md bg-muted p-1 font-mono text-sm">
          {(["login", "register"] as const).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`rounded py-2 transition ${mode === m ? "bg-background text-foreground" : "text-muted-foreground"}`}
            >
              {m === "login" ? "Sign in" : "Create account"}
            </button>
          ))}
        </div>
        <form onSubmit={submit} className="space-y-4">
          <Label text="Username"><input className="field" required value={user} onChange={(e) => setUser(e.target.value)} autoComplete="username" /></Label>
          <Label text="Password"><input className="field" type="password" required value={pass} onChange={(e) => setPass(e.target.value)} autoComplete={mode === "login" ? "current-password" : "new-password"} /></Label>
          <PrimaryBtn busy={busy}>{mode === "login" ? "Sign in" : "Create account"}</PrimaryBtn>
        </form>
        <div className="mt-6 flex justify-center gap-4 font-mono text-xs text-muted-foreground">
          <a href="https://youtu.be/CRtd6D4ZazI" target="_blank" rel="noopener noreferrer" className="hover:text-primary">YouTube ↗</a>
          <a href="https://t.me/CYBER_SECURITY_FORCES" target="_blank" rel="noopener noreferrer" className="hover:text-primary">Telegram ↗</a>
        </div>
      </section>
    </main>
  );
}

/* ---------------- Dashboard ---------------- */

function Dashboard({ session, refresh }: { session: Session; refresh: () => Promise<void> }) {
  const [name, setName] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [editing, setEditing] = useState<Project | null>(null);
  const [deleting, setDeleting] = useState<Project | null>(null);

  async function deploy(e: FormEvent) {
    e.preventDefault();
    if (!api.isHtml(file)) { toast.error("Only .html / .htm files are allowed."); return; }
    setBusy(true);
    try {
      await api.createSite(name, file!);
      toast.success("Deployed!");
      setName(""); setFile(null);
      await refresh();
    } catch (e) { toast.error(errMsg(e)); }
    finally { setBusy(false); }
  }

  return (
    <main className="mx-auto grid max-w-5xl gap-6 px-5 pb-16 lg:grid-cols-[380px_1fr]">
      <section className="animate-rise h-fit rounded-xl border bg-card p-6">
        <h2 className="flex items-center gap-2 text-lg font-semibold"><Rocket className="size-5 text-primary" /> New deployment</h2>
        <form onSubmit={deploy} className="mt-5 space-y-4">
          <Label text="Site name">
            <input className="field font-mono" required maxLength={40} value={name} onChange={(e) => setName(e.target.value)} placeholder="my-site" autoComplete="off" />
          </Label>
          <div className="truncate rounded-md bg-muted px-3 py-2 font-mono text-xs text-muted-foreground">
            {api.HOST_PREFIX}<span className="text-primary">{name.toLowerCase() || "name"}</span>
          </div>
          <DropZone file={file} onFile={setFile} />
          <PrimaryBtn busy={busy}><Rocket className="size-4" /> Deploy</PrimaryBtn>
        </form>
      </section>

      <section className="animate-rise rounded-xl border bg-card" style={{ animationDelay: "80ms" }}>
        <div className="flex items-center justify-between border-b px-6 py-4">
          <h2 className="text-lg font-semibold">Your sites</h2>
          <span className="rounded bg-muted px-2 py-0.5 font-mono text-xs">{session.projects.length}</span>
        </div>
        {session.projects.length === 0 ? (
          <div className="px-6 py-16 text-center text-muted-foreground">
            <FileCode2 className="mx-auto size-8 opacity-50" />
            <p className="mt-3">No sites yet — deploy your first file.</p>
          </div>
        ) : (
          <ul className="divide-y">
            {session.projects.map((p, i) => (
              <li key={p.id} className="animate-rise flex items-center gap-3 px-6 py-4" style={{ animationDelay: `${i * 50}ms` }}>
                <span className="grid size-9 shrink-0 place-items-center rounded-md bg-muted"><Globe className="size-4 text-primary" /></span>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium">{p.name}</p>
                  <a href={p.url} target="_blank" rel="noopener noreferrer" className="block truncate font-mono text-xs text-muted-foreground hover:text-primary">
                    {p.url.replace(/^https?:\/\//, "").replace(/\/$/, "")}
                  </a>
                </div>
                <IconBtn label="Open" href={p.url}><ArrowUpRight className="size-4" /></IconBtn>
                <IconBtn label="Edit" onClick={() => setEditing(p)}><Pencil className="size-4" /></IconBtn>
                <IconBtn label="Delete" danger onClick={() => setDeleting(p)}><Trash2 className="size-4" /></IconBtn>
              </li>
            ))}
          </ul>
        )}
      </section>

      {editing && <EditModal project={editing} onClose={() => setEditing(null)} refresh={refresh} />}
      {deleting && <DeleteModal project={deleting} onClose={() => setDeleting(null)} refresh={refresh} />}
    </main>
  );
}

function EditModal({ project, onClose, refresh }: { project: Project; onClose: () => void; refresh: () => Promise<void> }) {
  const [newName, setNewName] = useState(project.name);
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState<"rename" | "update" | null>(null);

  async function rename(e: FormEvent) {
    e.preventDefault();
    setBusy("rename");
    try { await api.renameProject(project, newName); toast.success("Renamed."); onClose(); await refresh(); }
    catch (e) { toast.error(errMsg(e)); } finally { setBusy(null); }
  }
  async function update(e: FormEvent) {
    e.preventDefault();
    if (!api.isHtml(file)) { toast.error("Only .html / .htm files are allowed."); return; }
    setBusy("update");
    try { await api.updateSite(project, file!); toast.success("Updated."); onClose(); await refresh(); }
    catch (e) { toast.error(errMsg(e)); } finally { setBusy(null); }
  }

  return (
    <Modal title={<>Edit <span className="font-mono text-primary">{project.name}</span></>} onClose={onClose}>
      <form onSubmit={rename} className="flex gap-2">
        <input className="field font-mono" required value={newName} onChange={(e) => setNewName(e.target.value)} />
        <button disabled={!!busy} className="shrink-0 rounded-md border px-4 text-sm font-medium transition hover:border-primary disabled:opacity-50">
          {busy === "rename" ? <Loader2 className="size-4 animate-spin" /> : "Rename"}
        </button>
      </form>
      <form onSubmit={update} className="mt-6 space-y-3">
        <p className="font-mono text-xs uppercase tracking-wider text-muted-foreground">Upload new version</p>
        <DropZone file={file} onFile={setFile} />
        <PrimaryBtn busy={busy === "update"}><UploadCloud className="size-4" /> Update site</PrimaryBtn>
      </form>
      <div className="mt-6">
        <p className="mb-2 font-mono text-xs uppercase tracking-wider text-muted-foreground">Versions</p>
        {project.versions.length === 0 ? (
          <p className="rounded-md bg-muted px-3 py-3 text-center text-sm text-muted-foreground">No versions yet.</p>
        ) : (
          <ul className="max-h-48 space-y-1 overflow-auto">
            {project.versions.map((v) => (
              <li key={v} className="flex items-center justify-between rounded-md bg-muted px-3 py-2 text-sm">
                <span className="font-mono">v{v}</span>
                <button type="button" onClick={() => api.downloadVersion(project, v).catch((e) => toast.error(errMsg(e)))} className="flex items-center gap-1 text-primary hover:underline"><Download className="size-3.5" /> Download</button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </Modal>
  );
}

function DeleteModal({ project, onClose, refresh }: { project: Project; onClose: () => void; refresh: () => Promise<void> }) {
  const [busy, setBusy] = useState(false);
  async function confirm() {
    setBusy(true);
    try { await api.removeProject(project); toast.success("Deleted."); onClose(); await refresh(); }
    catch (e) { toast.error(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal title="Delete site?" onClose={onClose}>
      <p className="text-muted-foreground">
        <span className="font-mono text-foreground">{project.name}</span> will be taken offline permanently.
      </p>
      <div className="mt-6 grid grid-cols-2 gap-2">
        <button onClick={onClose} className="rounded-md border py-2.5 text-sm font-medium hover:bg-accent">Cancel</button>
        <button onClick={confirm} disabled={busy} className="flex items-center justify-center rounded-md bg-destructive py-2.5 text-sm font-semibold text-destructive-foreground disabled:opacity-50">
          {busy ? <Loader2 className="size-4 animate-spin" /> : "Delete"}
        </button>
      </div>
    </Modal>
  );
}

/* ---------------- Bits ---------------- */

function Label({ text, children }: { text: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block font-mono text-xs uppercase tracking-wider text-muted-foreground">{text}</span>
      {children}
    </label>
  );
}

function PrimaryBtn({ busy, children }: { busy?: boolean; children: ReactNode }) {
  return (
    <button disabled={busy} className="flex w-full items-center justify-center gap-2 rounded-md bg-primary py-3 font-semibold text-primary-foreground transition hover:glow disabled:opacity-60">
      {busy ? <Loader2 className="size-4 animate-spin" /> : children}
    </button>
  );
}

function IconBtn({ label, href, onClick, danger, children }: { label: string; href?: string; onClick?: () => void; danger?: boolean; children: ReactNode }) {
  const cls = `grid size-9 shrink-0 place-items-center rounded-md border text-muted-foreground transition ${danger ? "hover:border-destructive hover:text-destructive" : "hover:border-primary hover:text-foreground"}`;
  return href
    ? <a href={href} target="_blank" rel="noopener noreferrer" aria-label={label} title={label} className={cls}>{children}</a>
    : <button onClick={onClick} aria-label={label} title={label} className={cls}>{children}</button>;
}

function DropZone({ file, onFile }: { file: File | null; onFile: (f: File | null) => void }) {
  const ref = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);
  return (
    <div
      onClick={() => ref.current?.click()}
      onDragOver={(e) => { e.preventDefault(); setOver(true); }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => { e.preventDefault(); setOver(false); onFile(e.dataTransfer.files[0] ?? null); }}
      className={`cursor-pointer rounded-md border border-dashed px-4 py-6 text-center transition ${over ? "border-primary bg-muted" : file ? "border-primary" : "hover:border-muted-foreground"}`}
    >
      <input ref={ref} type="file" accept=".html,.htm" hidden onChange={(e) => onFile(e.target.files?.[0] ?? null)} />
      <FileCode2 className={`mx-auto size-6 ${file ? "text-primary" : "text-muted-foreground"}`} />
      <p className="mt-2 truncate text-sm">{file ? file.name : "Drop an HTML file or click to browse"}</p>
    </div>
  );
}

function Modal({ title, onClose, children }: { title: ReactNode; onClose: () => void; children: ReactNode }) {
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-background/80 p-4 backdrop-blur-sm" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="animate-rise w-full max-w-md rounded-xl border bg-card p-6">
        <div className="mb-5 flex items-center justify-between">
          <h3 className="text-lg font-semibold">{title}</h3>
          <button onClick={onClose} aria-label="Close" className="text-muted-foreground hover:text-foreground"><X className="size-5" /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

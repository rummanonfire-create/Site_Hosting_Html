import { createRoot } from "react-dom/client";
import App from "./App";
import { Toaster } from "sonner";
import "./styles.css";

createRoot(document.getElementById("root")!).render(
  <>
    <App />
    <Toaster theme="dark" position="top-center" richColors />
  </>,
);

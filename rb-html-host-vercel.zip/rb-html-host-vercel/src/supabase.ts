import { createClient } from "@supabase/supabase-js";

// Same backend as the original app — accounts and sites are shared.
const URL =
  import.meta.env.VITE_SUPABASE_URL ||
  "https://c--071cdafe-bd8d-460a-a76f-3b65aac0f068-prod.lovable.cloud";
const KEY =
  import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ||
  "sb_publishable_cq9tllLBdeF_3emG-sLQGA_qZ1l7dw6";

export const supabase = createClient(URL, KEY);

import { supabase } from "./supabase";

// Usernames are mapped to an internal email so people sign in with just a username.
const EMAIL_DOMAIN = "users.webhost.app";
const toEmail = (u: string) => `${u.trim().toLowerCase()}@${EMAIL_DOMAIN}`;

export type Project = { id: string; name: string; versions: number[]; url: string };
export type Session = { username: string; projects: Project[] };

export const siteUrl = (name: string) => `${window.location.origin}/s/${name}`;
export const HOST_PREFIX = "/s/";

export const NAME_RE = /^[a-z0-9][a-z0-9-]{1,39}$/;
export const USER_RE = /^[a-z0-9_]{3,24}$/;

function friendly(msg: string) {
  if (/duplicate key|sites_name_key/i.test(msg)) return "That site name is already taken.";
  if (/sites_name_check/i.test(msg)) return "Site name: 2–40 lowercase letters, numbers or dashes.";
  if (/already registered/i.test(msg)) return "That username is taken.";
  if (/invalid login/i.test(msg)) return "Wrong username or password.";
  return msg;
}
const check = (error: { message: string } | null) => {
  if (error) throw new Error(friendly(error.message));
};

export async function getSession(): Promise<Session | null> {
  const { data } = await supabase.auth.getUser();
  if (!data.user) return null;
  const { data: rows, error } = await supabase
    .from("sites")
    .select("id,name,site_versions(version)")
    .order("created_at", { ascending: false });
  check(error);
  return {
    username: data.user.email?.split("@")[0] ?? "user",
    projects: (rows ?? []).map((r) => ({
      id: r.id,
      name: r.name,
      versions: (r.site_versions ?? []).map((v) => v.version).sort((a, b) => b - a),
      url: siteUrl(r.name),
    })),
  };
}

export async function auth(mode: "login" | "register", username: string, password: string) {
  const u = username.trim().toLowerCase();
  if (!USER_RE.test(u)) throw new Error("Username: 3–24 lowercase letters, numbers or _.");
  if (mode === "register") {
    const { error } = await supabase.auth.signUp({ email: toEmail(u), password });
    check(error);
  } else {
    const { error } = await supabase.auth.signInWithPassword({ email: toEmail(u), password });
    check(error);
  }
}

export const logout = () => supabase.auth.signOut();

async function addVersion(siteId: string, file: File) {
  const html = await file.text();
  const { data: last } = await supabase
    .from("site_versions").select("version").eq("site_id", siteId)
    .order("version", { ascending: false }).limit(1).maybeSingle();
  const { error } = await supabase
    .from("site_versions").insert({ site_id: siteId, version: (last?.version ?? 0) + 1, html });
  check(error);
}

export async function createSite(name: string, file: File) {
  const n = name.trim().toLowerCase();
  if (!NAME_RE.test(n)) throw new Error("Site name: 2–40 lowercase letters, numbers or dashes.");
  const { data, error } = await supabase.from("sites").insert({ name: n }).select("id").single();
  check(error);
  await addVersion(data!.id, file);
}

export const updateSite = (p: Project, file: File) => addVersion(p.id, file);

export async function removeProject(p: Project) {
  const { error } = await supabase.from("sites").delete().eq("id", p.id);
  check(error);
}

export async function renameProject(p: Project, newName: string) {
  const n = newName.trim().toLowerCase();
  if (!NAME_RE.test(n)) throw new Error("Site name: 2–40 lowercase letters, numbers or dashes.");
  const { error } = await supabase.from("sites").update({ name: n }).eq("id", p.id);
  check(error);
}

export async function downloadVersion(p: Project, v: number) {
  const { data, error } = await supabase
    .from("site_versions").select("html").eq("site_id", p.id).eq("version", v).single();
  check(error);
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([data!.html], { type: "text/html" }));
  a.download = `${p.name}-v${v}.html`;
  a.click();
  URL.revokeObjectURL(a.href);
}

export const isHtml = (f?: File | null) => !!f && /\.html?$/i.test(f.name);

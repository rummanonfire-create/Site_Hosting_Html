// Vercel serverless function: serves a hosted site's latest HTML at /s/<name>.
// The CSP sandbox header gives the page an opaque origin so uploaded scripts
// can't read the dashboard's cookies or storage.
const SUPABASE_URL =
  process.env.SUPABASE_URL || "https://c--071cdafe-bd8d-460a-a76f-3b65aac0f068-prod.lovable.cloud";
const SUPABASE_PUBLISHABLE_KEY =
  process.env.SUPABASE_PUBLISHABLE_KEY || "sb_publishable_cq9tllLBdeF_3emG-sLQGA_qZ1l7dw6";

export default async function handler(req, res) {
  const name = String(req.query.name || "").toLowerCase();
  if (!/^[a-z0-9][a-z0-9-]{1,39}$/.test(name)) {
    return res.status(404).type("text/plain").send("Not found");
  }
  try {
    const r = await fetch(`${SUPABASE_URL}/rest/v1/rpc/get_site_html`, {
      method: "POST",
      headers: { apikey: SUPABASE_PUBLISHABLE_KEY, "Content-Type": "application/json" },
      body: JSON.stringify({ _name: name }),
    });
    const html = r.ok ? await r.json() : null;
    if (!html) {
      return res.status(404).type("text/plain").send("Site not found");
    }
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.setHeader(
      "Content-Security-Policy",
      "sandbox allow-scripts allow-forms allow-popups allow-modals allow-downloads",
    );
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Cache-Control", "public, max-age=30");
    res.status(200).send(html);
  } catch (err) {
    console.error(err);
    res.status(500).type("text/plain").send("Server error");
  }
}
